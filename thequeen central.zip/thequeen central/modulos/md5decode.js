
const md5 = require("spark-md5")

function geraArray(inicio = 999, alvo = "hashtelefone") {

    return new Promise((resolve, reject) => {
        for (let index = 0; index < 999999; index++) {


            var current = ""
            
           
            var tamanho = index.toString().length
            if(tamanho == 1){
                current = `${inicio}0000${index}`
            }
            if(tamanho == 2){
                current = `${inicio}000${index}`
            }
            if(tamanho == 3){
                current = `${inicio}00${index}`
            }
            if(tamanho == 4){
                current = `${inicio}0${index}`
            }
            if(tamanho == 5){
                current = `${inicio}${index}`
            }
            if(tamanho == 6){
                current = `${inicio}${index}`
            }
 
            var encoded = md5.hash(current)
      
            if (encoded == alvo) {
                resolve(current)
            }
        }
    })
    

}

//by thequeen

module.exports.md5 = geraArray