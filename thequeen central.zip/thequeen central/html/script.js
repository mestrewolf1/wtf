function init() {
    document.getElementById('arquivo').addEventListener('change', handleFileSelect, false);
}

function replaceAll(string, search, replace) {
    return string.split(search).join(replace);
}

function handleFileSelect(event) {
    const reader = new FileReader()
    reader.onload = handleFileLoad;
    reader.readAsText(event.target.files[0])
}

function isValidCPF(cpf) {
    if (typeof cpf !== "string") return false
    cpf = cpf.replace(/[\s.-]*/igm, '')
    if (
        !cpf ||
        cpf.length != 11 ||
        cpf == "00000000000" ||
        cpf == "11111111111" ||
        cpf == "22222222222" ||
        cpf == "33333333333" ||
        cpf == "44444444444" ||
        cpf == "55555555555" ||
        cpf == "66666666666" ||
        cpf == "77777777777" ||
        cpf == "88888888888" ||
        cpf == "99999999999"
    ) {
        return false
    }
    var soma = 0
    var resto
    for (var i = 1; i <= 9; i++)
        soma = soma + parseInt(cpf.substring(i - 1, i)) * (11 - i)
    resto = (soma * 10) % 11
    if ((resto == 10) || (resto == 11)) resto = 0
    if (resto != parseInt(cpf.substring(9, 10))) return false
    soma = 0
    for (var i = 1; i <= 10; i++)
        soma = soma + parseInt(cpf.substring(i - 1, i)) * (12 - i)
    resto = (soma * 10) % 11
    if ((resto == 10) || (resto == 11)) resto = 0
    if (resto != parseInt(cpf.substring(10, 11))) return false
    return true
}

function handleFileLoad(event) {
    $("#comecar").removeAttr("disabled");
    // $("#parar").removeAttr("disabled");
    var mytmp = event.target.result
    mytmp = replaceAll(event.target.result, "\r\n", "\n")
    mytmp = replaceAll(mytmp, " ", "")
    console.log(mytmp);

    mytmp = mytmp.split("\n").filter((value, index, array) => {
        if (value.includes("|")) {
            var tmpvalue = value.split("|")[0]
        } else {
            var tmpvalue = value
        }

        return isValidCPF(tmpvalue)
    })

    app.lista = mytmp.join("\n")
    app.analytics.carregadas = `Carregadas neste arquivo: ${app.lista.split("\n").length - 1}`
    document.getElementById('resultadoarquivo').textContent = app.lista;
}

$(document).ready(function () {

    // $(".form-check-label").change((event) => {

    //     console.log("testando");

    // var checked = event.originalEvent.target.checked;
    // var modulo = event.originalEvent.target.nextSibling.textContent.split("\n")[0];

    // // console.log(modulo);

    // app.checkers = app.checkers.map((value) => {
    //     if (modulo.includes(value.name)) {
    //         value.checked = checked
    //         return value
    //     } else {
    //         return value
    //     }
    // })

    // })

    $("#erroModal").on('shown.bs.modal', function () {
        $("#educ").css("opacity", 0.5)
    })

    $("#erroModal").on('hidden.bs.modal', function () {
        $("#educ").css("opacity", 1)
    })

    $("#educ").on('hidden.bs.modal', function () {
        $("#educ").modal('show')
    })


    //QUANDO CLICAR NO BOTAO DE MOSTRAR.

    $("#comecar").click(function () {

        var mylista = replaceAll(app.lista, "\r", "").split("\n")
        var options = {
            method: 'POST',
            url: `http://${window.location.hostname}:9771/bmg`,
            headers: { 'Content-Type': 'application/json' },
            data: { message: mylista, trabalhadores: app.trabalhadores, checkers: app.checkers }
        };

        axios.request(options).then(function (response) {
            app.status = "STATUS: TESTANDO"
            // console.log(response.data);
        }).catch(function (error) {
            console.error(error);
        });
    })

    setInterval(function () {
        var options = { method: 'GET', url: `http://${window.location.hostname}:9771/output` };
        var options2 = { method: 'GET', url: `http://${window.location.hostname}:9771/info` };

        axios.request(options).then(function (response) {
            if (response.data.includes("APROVADO")) {

                app.aprovadas = response.data.split("\r\n").filter((value) => {
                    return value.includes("APROVADO")
                }).join("\r\n")

                app.analytics.aprovadas = `Aprovadas (total gerenciador): ${response.data.split("APROVADO").length}`
            }

            if (response.data.includes("REPROVADO")) {
                app.reprovadas = response.data.split("\r\n").filter((value) => {
                    return value.includes("REPROVADO")
                }).join("\r\n")

                app.analytics.reprovadas = `Reprovadas (total gerenciador): ${response.data.split("REPROVADO").length - 1}`
            }
        }).catch(function (error) {
            console.error(error);
        });
        axios.request(options2).then(function (response) {
            app.repetidas = response.data.repetidas
            if (app.checkers.length === 0) {
                app.checkers = response.data.checkers
            }
        }).catch(function (error) {
            console.error(error);
        });

        if(app.analytics.aprovadas !== "Aprovadas (total gerenciador): 0"){
            app.status = "STATUS: TESTANDO"
        }
        if(app.analytics.reprovadas !== "Reprovadas (total gerenciador): 0"){
            app.status = "STATUS: TESTANDO"
        }

    }, 1000)

    $(".btn-mostralista").click(function () {


        if (app.lista === "") {
            app.modal_body = "Você precisa selecionar o arquivo da lista antes."
            $("#erroModal").modal("show")
        } else {
            $("#esm").slideToggle(1800)
        }
    })
})



var app = new Vue({
    el: "#app",
    data: {
        analytics: {
            aprovadas: "Aprovadas (total do gerenciador): 0",
            reprovadas: "Reprovadas (total do gerenciador): 0",
            carregadas: "Carregadas: 0",
        },
        alerta: {
            inicio: "Aviso!",
            mensagem: "Você precisa sair do modo edição de lista para iniciar o teste.",
        },
        checkers: [],
        trabalhadores: 7,
        aprovadas: "",
        reprovadas: "",
        status: "STATUS: PARADO",
        modal_title: "Ooops!",
        modal_body: "",
        modal_icon: "folder_open",
        lista: "",
        contentEditable: "false",
    },
    methods: {
        editarLista: function (event) {

            if (app.contentEditable === "true") {
                $("#comecar").removeAttr("disabled");

                $("#alerta").removeClass("show")
                app.contentEditable = "false"
                $("#resultadoarquivo")[0].textContent = replaceAll($("#resultadoarquivo")[0].innerText, '\r\n', '\n')
                app.lista = $("#resultadoarquivo")[0].textContent
                $("#esm").slideToggle(470)
            } else {
                $("#comecar").attr("disabled", "disabled");
                app.modal_body = "A partir do atual momento só será possível começar o teste quando voce finalizar sua edição."
                app.modal_title = "Aviso"
                app.modal_icon = "edit"
                $("#erroModal").modal("show")
                $("#alerta").addClass("show")
                app.contentEditable = "true"
            }
        },
        mostrarAprovadas: function (event) {
            app.modal_title = "APROVADAS"
            app.modal_body = app.aprovadas
            app.modal_icon = "check"
            $("#erroModal").modal()
        },
        mostrarReprovadas: function (event) {
            app.modal_title = "REPROVADAS"
            app.modal_body = app.reprovadas
            app.modal_icon = "check"
            $("#erroModal").modal()
        },

        mostrarRepetidas: function (event) {
            app.modal_title = "REPETIDAS (NAO FORAM RETESTADAS!!)"
            app.modal_body = app.repetidas
            app.modal_icon = "check"
            $("#erroModal").modal()
        },

        atualizarCarregadas: function (event) {

            app.analytics.carregadas = `Carregadas: ${event.target.innerText.split("\n").length - 1}`

        },

        defineCheckers: function (event) {

            var checked = event.target.checked;
            var modulo = event.target.nextSibling.textContent.split("\n")[0];

            // console.log(modulo);

            app.checkers = app.checkers.map((value) => {
                if (modulo.includes(value.name)) {
                    value.checked = checked
                    return value
                } else {
                    return value
                }
            })

        },
        defineTrabalhadores: function (event) {
            $(".valueSpan2").html(`VELOCIDADE: ${event.target.value}`)
            app.trabalhadores = parseInt(event.target.value)
        },
        btnResetar: function (event) {

            var options = {
                method: 'GET',
                url: `http://${window.location.hostname}:9771/reiniciar`,
            };

            axios.request(options).then(function (response) {
                app.modal_title = "Nota"
                app.modal_body = "O servidor foi reiniciado, toda informacao foi resetada e a lista inserida começara do 0."
                app.modal_icon = "app_settings_alt"
                $("#erroModal").modal()
            }).catch(function (error) {
                app.modal_title = "Nota"
                app.modal_body = JSON.stringify(error)
                app.modal_icon = "app_settings_alt"
                $("#erroModal").modal()
            });


        }
    }
});