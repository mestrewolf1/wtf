
const express = require('express')
const { fork, exec } = require('child_process')
const { type } = require('os')
var bodyParser = require('body-parser')
const app = express()
const port = 9771

const fs = require('fs')
const { promisify } = require('util')

var output = ""

var repetidas = ""

var testado = 0

var filhos = [
  { name: "null", fork: null }
]

app.use(bodyParser.json({ limit: '50mb' }))
app.use(express.static("html"))
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})

var processando = {}

var listasConcluidas = 0

app.get('/reiniciar', function (req, res) {
  var script = exec("pm2 restart all")

  script.stdout.on('data', function (data) {
    console.log("reiniciado");
    res.status(200).send("reiniciado")
  });

  script.stderr.on('data', function (data) {
    res.status(400).send(data)
  });
})

app.post("/bmg", function (req, res) {

  // console.log(req.body);

  var testadores = req.body.checkers


  testadores.forEach(function (value) {
    if (value.checked === true) {

      var tmp = filhos.filter((filho) => { if (filho.name === value.name) { return filho; } });

      if (tmp.length === 0) {
        filhos.push({ name: value.name, fork: fork(__dirname + '/modulos/' + value.name) })
        var child = filhos.filter((filho) => { if (filho.name === value.name) { return filho; } })[0].fork
      } else {
        var child = tmp[0].fork
      }


      // process.exit(0)

      child.on('message', (message) => {

        if (typeof message == "object") {
          processando = message.processando
          listasConcluidas = message.listasConcluidas
        } else {


          if (output.includes(message) === false) {
            output += message + "\r\n"
            testado += 1
          } else {
            repetidas += message + "\r\n"
          }



        }

      });

      child.send(req.body)

    }
  })



  res.send({})

})


app.get("/output", function (req, res) {
  res.send(output)
})

app.get("/info", function (req, res) {

  var arrmodulos = fs.readdirSync("./modulos");

  arrmodulos = arrmodulos.map((value) => {
    return {
      name: value,
      checked: false
    }
  })

  // console.log(arrmodulos)

  res.send({ repetidas: repetidas, checkers: arrmodulos, filhos: filhos, processando: processando, listasConcluidas: listasConcluidas })
})
